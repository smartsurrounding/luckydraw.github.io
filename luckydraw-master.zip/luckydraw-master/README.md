Lucky Draw
==========

Enhanced by Sammy Fung, based on Haggen's previous work. Hong Kong Open Source Conference 2016 is example theme.

GitHub: https://github.com/sammyfung/luckydraw

Demo on GitHub Page: https://sammyfung.github.io/luckydraw
